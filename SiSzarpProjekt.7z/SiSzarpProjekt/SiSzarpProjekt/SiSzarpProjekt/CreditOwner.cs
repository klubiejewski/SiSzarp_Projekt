﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SiSzarpProjekt
{
    public class CreditOwner
    {
        private int creditScore;
        private string clientName;
        private double totalAmountDue;
        private double amountDueLeft;
        private bool payedOnTime;

        public CreditOwner(int creditScore, string clientName, double totalAmountDue, double amountDueLeft, bool payedOnTime)
        {
            this.creditScore = creditScore;
            this.clientName = clientName;
            this.totalAmountDue = totalAmountDue;
            this.amountDueLeft = amountDueLeft;
            this.payedOnTime = payedOnTime;
        }
        public int getCreditScore()
        {
            return creditScore;
        }
        public string getClientName()
        {
            return clientName;
        }
        public double getTotalAmountDue()
        {
            return totalAmountDue;
        }
        public double getAmountDueLeft()
        {
            return amountDueLeft;
        }
        public bool getIsPayedOnTime()
        {
            return payedOnTime;
        }
        public void showCreditOwner()
        {
            Console.WriteLine(getCreditScore() + " " + getClientName() + " " + getTotalAmountDue() + " " + getAmountDueLeft() + " " + getIsPayedOnTime());
        }
    }
}
