﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiSzarpProjekt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Person person = new Person("Kacper", "Superson", 07, false, 'M');
            CreditOwner creditOwner = new CreditOwner(2, person.getName(), 5313248, 4202137, true);
            Bank bank = new Bank("Milenium", 999999);

            person.showPerson();
            creditOwner.showCreditOwner();
            bank.showBank();
        Console.ReadKey();
        }
    }
}
