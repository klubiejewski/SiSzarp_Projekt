﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SiSzarpProjekt
{
    public class Bank
    {
        private string bankName;
        private double totalNumberOfLoans;

        public Bank(string bankName, double totalNumberOfLoans)
        {
            this.bankName = bankName;
            this.totalNumberOfLoans = totalNumberOfLoans;
        }
        public string getBankName()
        {
            return bankName;
        }
        public double getTotalNumberOfLoans()
        {
            return totalNumberOfLoans;
        }
        public void showBank()
        {
            Console.WriteLine(getBankName() + " " + getTotalNumberOfLoans());
        }
    }
}
