﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiSzarpProjekt
{
    public class Person
    {
        private string name;
        private string surname;
        private int pesel;
        private bool canTakeALoan;
        private char gender;

        public Person(string name, string surname, int pesel, bool canTakeALoan, char gender)
        {
            this.name = name;
            this.surname = surname;
            this.pesel = pesel;
            this.canTakeALoan = canTakeALoan;
            this.gender = gender;
        }
        public string getName()
        {
            return name;
        }
        public string getSurname()
        {
            return surname;
        }
        public int getPesel()
        {
            return pesel;
        }
        public bool getCanTakeALoan()
        {
            return canTakeALoan;
        }
        public char getGender()
        {
            return gender;
        }
        public void showPerson()
        {
            Console.WriteLine(getName() + " " + getSurname() + " " + getPesel() + " " + getCanTakeALoan() + " " + getGender());
        }
    }
}
